// components/BottomTabBar.js
import React from 'react';
import { View, TouchableOpacity, Image, StyleSheet, Text } from 'react-native';
import { useNavigation } from '@react-navigation/native';  // Importando useNavigation

const BottomTabBar = ({ cartCount }) => {
  const navigation = useNavigation();  // Usando o hook useNavigation

  return (
    <View style={styles.container}>
      {/* Ícone Home */}
      <TouchableOpacity
        style={styles.tabButton}
        onPress={() => navigation.navigate('Home')}
      >
        <Image
          source={{ uri: 'https://cdn-icons-png.flaticon.com/512/25/25694.png' }}  
          style={styles.icon}
        />
        <Text style={styles.tabLabel}>Home</Text>
      </TouchableOpacity>

      {/* Ícone Carrinho */}
      <TouchableOpacity
        style={styles.tabButton}
        onPress={() => navigation.navigate('Cart')}
      >
        <Image
          source={{ uri: 'https://cdn-icons-png.flaticon.com/512/126/126510.png' }}  
          style={styles.icon}
        />
        {cartCount > 0 && <View style={styles.badge}><Text style={styles.badgeText}>{cartCount}</Text></View>}
        <Text style={styles.tabLabel}>Carrinho</Text>
      </TouchableOpacity>

      {/* Ícone Perfil */}
      <TouchableOpacity
        style={styles.tabButton}
        onPress={() => navigation.navigate('Profile')}
      >
        <Image
          source={{ uri: 'https://cdn-icons-png.flaticon.com/512/4675/4675159.png' }}  
          style={styles.icon}
        />
        <Text style={styles.tabLabel}>Perfil</Text>
      </TouchableOpacity>

      {/* Ícone Pedidos */}
      <TouchableOpacity
        style={styles.tabButton}
        onPress={() => navigation.navigate('Orders')}
      >
        <Image
          source={{ uri: 'https://cdn-icons-png.flaticon.com/512/5218/5218542.png' }}  
          style={styles.icon}
        />
        <Text style={styles.tabLabel}>Pedidos</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#0f6fc0',  
    paddingVertical: 10,
    flexDirection: 'row',
    justifyContent: 'space-evenly',  
    alignItems: 'center',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -5 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
  },
  tabButton: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  icon: {
    width: 30,  
    height: 30,
    resizeMode: 'contain', 
  },
  badge: {
    position: 'absolute',
    top: -5,
    right: -5,
    backgroundColor: '#FF6347',
    width: 20,
    height: 20,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  badgeText: {
    color: '#fff',
    fontSize: 12,
    fontWeight: 'bold',
  },
  tabLabel: {
    color: '#fff',
    fontSize: 10,  
    marginTop: 4,  
  },
});

export default BottomTabBar;
