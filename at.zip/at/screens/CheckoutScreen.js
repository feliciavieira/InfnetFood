// screens/CheckoutScreen.js
import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';

const CheckoutScreen = ({ route, navigation }) => {
  const { cartItems = [], total = 0 } = route.params || {};  
  const [address, setAddress] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');

  useEffect(() => {
    const requestPermissions = async () => {
      const { status } = await Notifications.requestPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permissão de notificação', 'Precisamos de permissão para enviar notificações.');
      }
    };
    requestPermissions();
  }, []);

  const handleCheckout = async () => {
    if (!address || !paymentMethod) {
      Alert.alert('Erro', 'Por favor, preencha todos os campos obrigatórios.');
      return;
    }

    // Cria o pedido com as informações do carrinho
    const order = {
      id: Date.now().toString(),  
      date: new Date().toLocaleDateString(),
      total: total,
      items: cartItems,
      address,
      paymentMethod,
    };

    try {
     
      const storedOrders = await AsyncStorage.getItem('orders');
      const orders = storedOrders ? JSON.parse(storedOrders) : [];

      
      orders.push(order);

      // Salva os pedidos no AsyncStorage
      await AsyncStorage.setItem('orders', JSON.stringify(orders));

     
      await AsyncStorage.removeItem('cartItems');

      
      Alert.alert('Pedido Realizado', 'Seu pedido foi finalizado com sucesso!');  

      
      schedulePreparationNotification();

      
      navigation.navigate('Orders');
    } catch (error) {
      console.error('Erro ao salvar o pedido:', error);
    }
  };

  //agendar a notificação
  const schedulePreparationNotification = async () => {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "Pedido em Preparação",
        body: "Seu pedido está sendo preparado e em breve será enviado para entrega.",
        data: { type: 'order_preparation' },
      },
      trigger: {
        seconds: 5, 
      },
    });
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Revisão do Pedido</Text>
      
      <View style={styles.cartContainer}>
        <Text style={styles.cartTitle}>Itens no Carrinho:</Text>
        {cartItems.map(item => (
          <View key={item.id} style={styles.cartItem}>
            <Text style={styles.itemName}>{item.name}</Text>
            <Text style={styles.itemDetails}>
              {item.quantity} x R$ {item.price.toFixed(2)}
            </Text>
          </View>
        ))}
        <Text style={styles.totalText}>Total: R$ {total.toFixed(2)}</Text>
      </View>
      
      <Text style={styles.label}>Endereço de Entrega:</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite seu endereço"
        value={address}
        onChangeText={setAddress}
      />
      
      <Text style={styles.label}>Método de Pagamento:</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite o método de pagamento"
        value={paymentMethod}
        onChangeText={setPaymentMethod}
      />
      
      <TouchableOpacity style={styles.checkoutButton} onPress={handleCheckout}>
        <Text style={styles.checkoutButtonText}>Finalizar Pedido</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f9f9f9',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#333',
    textAlign: 'center',
    marginBottom: 20,
  },
  cartContainer: {
    marginBottom: 20,
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 5,
    elevation: 5,
  },
  cartTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  cartItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  itemName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#333',
  },
  itemDetails: {
    fontSize: 16,
    color: '#555',
  },
  totalText: {
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'right',
    marginTop: 10,
    color: '#007BFF',
  },
  label: {
    fontSize: 16,
    marginTop: 20,
    color: '#333',
  },
  input: {
    height: 40,
    borderColor: '#ccc',
    borderWidth: 1,
    marginTop: 10,
    paddingLeft: 10,
    borderRadius: 5,
    backgroundColor: '#fff',
  },
  checkoutButton: {
    backgroundColor: '#28a745',
    padding: 15,
    borderRadius: 10,
    marginTop: 30,
    alignItems: 'center',
  },
  checkoutButtonText: {
    color: '#fff',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

export default CheckoutScreen;
