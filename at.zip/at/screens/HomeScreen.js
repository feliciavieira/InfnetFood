//screens/HomeScreen.js
import React from 'react';
import { View, FlatList, Text, TouchableOpacity, Image, StyleSheet } from 'react-native';
import colors from '../styles/colors'; // Supondo que você tenha um arquivo de cores

const categories = [
  { id: '1', name: 'Lanches', image: require('../img/lanches.jpg') },
  { id: '2', name: 'Bebidas', image: require('../img/bebidas.jpg') },
  { id: '3', name: 'Sobremesas', image: require('../img/sobremesas.jpg') },
];

export default function HomeScreen({ navigation }) {

  
  const navigateToProducts = (category) => {
    navigation.navigate('Products', { category });
  };

  
  const renderCategory = ({ item }) => (
    <TouchableOpacity
      style={styles.categoryItem}
      onPress={() => navigateToProducts(item.name)}
    >
      <Image source={item.image} style={styles.categoryImage} />
      <Text style={styles.categoryName}>{item.name}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Categorias</Text>
      <FlatList
        data={categories}
        renderItem={renderCategory}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContainer}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    justifyContent: 'flex-start', 
    alignItems: 'center', 
    backgroundColor: '#f5f5f5', // fundo suave e claro
    paddingHorizontal: 20,
  },
  title: { 
    fontSize: 28, 
    fontWeight: 'bold', 
    color: '#333', 
    marginVertical: 30,
    textAlign: 'center',
  },
  listContainer: {
    width: '100%',
    paddingBottom: 20,
  },
  categoryItem: {
    backgroundColor: '#0f6fc0', // azul para cada item
    marginVertical: 12, // espaçamento entre os itens
    borderRadius: 15, // bordas mais arredondadas
    paddingVertical: 25,
    paddingHorizontal: 20,
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
    shadowColor: '#000', 
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 6, // sombra mais forte
    transform: [{ scale: 1.02 }], // leve aumento visual para interatividade
  },
  categoryImage: {
    width: 120, // imagem maior
    height: 120,
    borderRadius: 18, // bordas mais arredondadas nas imagens
    marginBottom: 20,
    resizeMode: 'cover',
  },
  categoryName: {
    fontSize: 20, // fonte maior
    fontWeight: 'bold',
    color: 'white', // cor do texto
    textAlign: 'center',
  },
});
