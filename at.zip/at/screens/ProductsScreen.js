import React, { useState, useEffect } from 'react';
import { View, FlatList, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import LottieView from 'lottie-react-native'; // Importando a animação
import colors from '../styles/colors';

const productsData = {
  Lanches: [
    { id: '1', name: 'Hambúrguer', price: 20.0, image: require('../img/hamburguer.jpeg') },
    { id: '2', name: 'Pizza', price: 30.0, image: require('../img/pizza.jpg') },
    { id: '3', name: 'Coxinha', price: 8.0, image: require('../img/cozinha.jpeg') },
    { id: '4', name: 'Empadão de Camarão', price: 27.0, image: require('../img/empadao.jpg') },
  ],
  Bebidas: [
    { id: '1', name: 'Coca-Cola', price: 8.0, image: require('../img/coca.jpeg') },
    { id: '2', name: 'Água', price: 4.0, image: require('../img/agua.jpg') },
    { id: '3', name: 'Suco de Caju', price: 9.0, image: require('../img/sucodecaju.jpg') },
    { id: '4', name: 'Laramora', price: 15.0, image: require('../img/laramora.jpeg') },
    { id: '5', name: 'Suco de Maracuja', price: 9.0, image: require('../img/sucodemaracuja.jpeg') },
  ],
  Sobremesas: [
    { id: '1', name: 'Bolo de Chocolate', price: 15.0, image: require('../img/bolo1.jpg') },
    { id: '2', name: 'Sorvete', price: 12.0, image: require('../img/sorvete.jpeg') },
    { id: '3', name: 'Bala', price: 7.0, image: require('../img/bala.jpg') },
    { id: '4', name: 'Copo da Felicidade', price: 32.0, image: require('../img/copofelicidade.jpg') },
    { id: '5', name: 'Bolo de Cenoura', price: 15.0, image: require('../img/bolocenoura.jpg') },
    { id: '6', name: 'Morangoffe', price: 25.0, image: require('../img/morangoffe.jpg') },
  ],
};

export default function ProductsScreen({ route }) {
  const { category } = route.params || { category: 'Lanches' };
  const [cart, setCart] = useState([]);
  const [showAnimation, setShowAnimation] = useState(false); // Estado para controlar a animação
  const navigation = useNavigation();

  useEffect(() => {
    const loadCart = async () => {
      try {
        const storedCart = await AsyncStorage.getItem('cart');
        if (storedCart) {
          setCart(JSON.parse(storedCart));
        }
      } catch (error) {
        console.log(error);
      }
    };
    loadCart();
  }, []);

  const addItemToCart = async (item) => {
    const updatedCart = [...cart];
    const existingItem = updatedCart.find((cartItem) => cartItem.id === item.id);

    if (existingItem) {
      existingItem.quantity += 1;
    } else {
      updatedCart.push({ ...item, quantity: 1 });
    }

    setCart(updatedCart);

    // Exibindo animação ao adicionar item
    setShowAnimation(true);
    setTimeout(() => setShowAnimation(false), 1000); // Esconde a animação após 1 segundo

    
    try {
      await AsyncStorage.setItem('cart', JSON.stringify(updatedCart));
    } catch (error) {
      console.log('Erro ao salvar carrinho', error);
    }
  };

  const navigateToCart = () => {
    navigation.navigate('Cart', { cart });
  };

  const renderProduct = ({ item }) => (
    <TouchableOpacity style={styles.productItem} onPress={() => addItemToCart(item)}>
      <Image source={item.image} style={styles.productImage} />
      <Text style={styles.productName}>{item.name}</Text>
      <Text style={styles.productPrice}>R$ {item.price.toFixed(2)}</Text>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>{category}</Text>

      {/* Exibindo animação ao adicionar item ao carrinho */}
      {showAnimation && (
        <LottieView
          source={require('../shopping-cart.json')} // Imagem da animação
          autoPlay
          loop={false}
          style={styles.animation}
        />
      )}

      <FlatList
        data={productsData[category] || []}
        renderItem={renderProduct}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContainer}
      />

      <TouchableOpacity style={[styles.cartButton, cart.length === 0 && styles.cartButtonDisabled]} onPress={navigateToCart} disabled={cart.length === 0}>
        <Text style={styles.cartButtonText}>Ir para o Carrinho</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    backgroundColor: colors.white,
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: colors.primary,
    marginBottom: 20,
  },
  listContainer: {
    width: '100%',
  },
  productItem: {
    backgroundColor: '#f9f9f9',
    padding: 15,
    marginVertical: 10,
    borderRadius: 8,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 5,
    elevation: 3,
  },
  productImage: {
    width: 120,
    height: 120,
    borderRadius: 10,
    marginBottom: 10,
  },
  productName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: colors.primary,
    marginBottom: 5,
  },
  productPrice: {
    fontSize: 16,
    color: colors.secondary,
  },
  cartButton: {
    marginTop: 20,
    padding: 15,
    backgroundColor: colors.primary,
    borderRadius: 8,
    width: '80%',
    alignItems: 'center',
  },
  cartButtonText: {
    fontSize: 18,
    color: '#fff',
  },
  cartButtonDisabled: {
    backgroundColor: '#aaa',
  },
  animation: {
    width: 150,
    height: 150,
    marginBottom: 20,
  },
});
