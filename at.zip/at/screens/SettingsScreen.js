import React from 'react';
import { View, Text, StyleSheet, Switch } from 'react-native';

const SettingsScreen = ({ theme, setTheme }) => {
  const toggleTheme = () => {
    setTheme((prevTheme) => (prevTheme === 'light' ? 'dark' : 'light'));
  };

  return (
    <View style={styles.container}>
      <Text style={[styles.text, { color: theme === 'light' ? '#000' : '#fff' }]}>
        Tema atual: {theme === 'light' ? 'Claro' : 'Escuro'}
      </Text>
      <View style={styles.switchContainer}>
        <Text style={[styles.text, { color: theme === 'light' ? '#000' : '#fff' }]}>
          Alternar tema
        </Text>
        <Switch
          value={theme === 'dark'}
          onValueChange={toggleTheme}
          thumbColor={theme === 'dark' ? '#bb86fc' : '#6200ea'}
        />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  text: {
    fontSize: 18,
    marginVertical: 10,
  },
  switchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 20,
  },
});

export default SettingsScreen;
