import React from 'react';
import { render } from '@testing-library/react-native';
import CategoriesScreen from '../screens/CategoriesScreen';

describe('CategoriesScreen', () => {
  it('deve exibir a lista de categorias corretamente', () => {
    
    const categories = ['Lanches', 'Bebidas', 'Sobremesas'];

    
    const { getByText } = render(<CategoriesScreen categories={categories} />);

    categories.forEach(category => {
      expect(getByText(category)).toBeTruthy();
    });
  });
});
