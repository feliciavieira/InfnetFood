import React, { useState } from 'react';
import { Text } from 'react-native';  
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs'; 

import HomeScreen from './screens/HomeScreen';
import ProductsScreen from './screens/ProductsScreen';
import LoginScreen from './screens/LoginScreen';
import SignUpScreen from './screens/SignUpScreen';
import ProfileScreen from './screens/ProfileScreen';
import CartScreen from './screens/CartScreen';
import CheckoutScreen from './screens/CheckoutScreen';  
import OrdersScreen from './screens/OrdersScreen';
import BottomTabBar from './components/BottomTabBar';  

const Stack = createStackNavigator();
const Tab = createBottomTabNavigator(); 
export default function App() {
  const [cartCount, setCartCount] = useState(3); 

  return (
    <NavigationContainer>
      <Stack.Navigator initialRouteName="Login">
        {/* Tela de Login */}
        <Stack.Screen
          name="Login"
          component={LoginScreen}
          options={{ headerShown: false }}
        />
        {/* Tela de Cadastro */}
        <Stack.Screen
          name="SignUp"
          component={SignUpScreen}
          options={{ title: 'InfnetFood' }}
        />
        
        {/* Navegação para a parte principal do app (BottomTabNavigator) */}
        <Stack.Screen
          name="Main"
          component={BottomTabs}  
          options={{ headerShown: false }}  
        />

        {/* Tela de Checkout - Adicione a tela de Checkout */}
        <Stack.Screen
          name="Checkout"
          component={CheckoutScreen}
          options={{ title: 'Checkout' }}  
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}


function BottomTabs() {
  return (
    <Tab.Navigator>
      {/* Tela Home */}
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{ title: 'Home' }}
      />
      {/* Tela de Produtos */}
      <Tab.Screen
        name="Products"
        component={ProductsScreen}
        options={{ title: 'Produtos' }}
      />
      {/* Tela de Perfil */}
      <Tab.Screen
        name="Profile"
        component={ProfileScreen}
        options={{ title: 'Perfil' }}
      />
      {/* Tela de Pedidos */}
      <Tab.Screen
        name="Orders"
        component={OrdersScreen}
        options={{ title: 'Pedidos' }}
      />
      {/* Tela de Carrinho */}
      <Tab.Screen
        name="Cart"
        component={CartScreen}
        options={{ title: 'Carrinho' }}
      />
    </Tab.Navigator>
  );
}
